# ToDoLite v1.4 - Archive System

## 🎉 Major Features

### 📦 Archive System
- **Archive completed/cancelled tasks** - Keep your main list clean
- **Restore archived tasks** - Bring tasks back to their original status
- **Archive protection** - Prevent accidental editing of archived tasks
- **Archive statistics** - Track archived tasks by status

### 🔒 Security & Reliability
- **Edit protection** - Archived tasks cannot be modified
- **Status preservation** - Original status is saved and restored
- **Comment support** - Add notes to archived tasks

### 🎨 UI Improvements
- **Archive button** - Easy access in mode switcher
- **Visual feedback** - Clear messages about edit restrictions
- **Agile mode** - Renamed from "Kanban" for terminology accuracy

## 🚀 How to Use

### Archiving Tasks
1. Complete a task (status "Done" or "Cancelled")
2. Click "📦 Archive" button in task card
3. Task disappears from main list and appears in archive

### Restoring Tasks
1. Go to "📦 Archive"
2. Find the task you need
3. Click "🔄 Restore"
4. Task returns to its original status

## 🔄 Backward Compatibility
- ✅ All existing tasks preserved
- ✅ Automatic database migration
- ✅ All settings and comments preserved
- ✅ Seamless upgrade from v1.1

## 🗄️ Database Changes
New fields added:
- `archived` - Archive flag (BOOLEAN)
- `archived_at` - Archive timestamp (TIMESTAMP)  
- `archived_from_status` - Original status before archiving (TEXT)

---

**Version:** v1.4  
**Date:** September 19, 2025  
**Compatibility:** Windows 10/11, Python 3.8+
