#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ToDoLite - Упрощенная система логирования
"""

import sys
from datetime import datetime
from typing import Optional

class Colors:
    """ANSI цветовые коды"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    
    # Цвета текста
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Яркие цвета
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'

class SimpleLogger:
    """
    Упрощенный логгер с цветным выводом
    """
    
    def __init__(self, name: str = "ToDoLite", debug: bool = False):
        self.name = name
        self.debug = debug
        self.colors = {
            'DEBUG': Colors.DIM + Colors.WHITE,
            'INFO': Colors.BRIGHT_CYAN,
            'SUCCESS': Colors.BRIGHT_GREEN,
            'WARNING': Colors.BRIGHT_YELLOW,
            'ERROR': Colors.BRIGHT_RED,
            'CRITICAL': Colors.BOLD + Colors.BRIGHT_RED,
            'TASK': Colors.BRIGHT_MAGENTA,
            'DATABASE': Colors.BRIGHT_BLUE,
            'HTTP': Colors.CYAN,
            'FORM': Colors.YELLOW,
            'AUTH': Colors.BRIGHT_BLUE,
            'CONFIG': Colors.BRIGHT_MAGENTA,
            'BACKUP': Colors.BRIGHT_GREEN,
            'REMINDER': Colors.BRIGHT_YELLOW,
            'NOTIFICATION': Colors.BRIGHT_CYAN
        }
    
    def _log(self, level: str, message: str, category: str = ""):
        """Внутренний метод логирования"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        color = self.colors.get(level, Colors.WHITE)
        reset = Colors.RESET
        
        # Форматируем сообщение
        if category:
            formatted_message = f"{color}[{timestamp}] {level:<8} [{category}] {message}{reset}"
        else:
            formatted_message = f"{color}[{timestamp}] {level:<8} {message}{reset}"
        
        # Выводим в консоль
        print(formatted_message, file=sys.stdout if level in ['INFO', 'SUCCESS', 'DEBUG'] else sys.stderr)
        
        # Принудительно сбрасываем буфер
        sys.stdout.flush()
        sys.stderr.flush()
    
    def debug(self, message: str, category: str = ""):
        """Логирование отладочной информации"""
        if self.debug:
            self._log("DEBUG", message, category)
    
    def info(self, message: str, category: str = ""):
        """Логирование информационных сообщений"""
        self._log("INFO", message, category)
    
    def success(self, message: str, category: str = ""):
        """Логирование успешных операций"""
        self._log("SUCCESS", message, category)
    
    def warning(self, message: str, category: str = ""):
        """Логирование предупреждений"""
        self._log("WARNING", message, category)
    
    def error(self, message: str, category: str = ""):
        """Логирование ошибок"""
        self._log("ERROR", message, category)
    
    def critical(self, message: str, category: str = ""):
        """Логирование критических ошибок"""
        self._log("CRITICAL", message, category)
    
    # Специализированные методы логирования
    def task(self, message: str, category: str = ""):
        """Логирование операций с задачами"""
        self._log("TASK", message, category)
    
    def database(self, message: str, category: str = ""):
        """Логирование операций с базой данных"""
        self._log("DATABASE", message, category)
    
    def http(self, message: str, category: str = ""):
        """Логирование HTTP запросов"""
        self._log("HTTP", message, category)
    
    def form(self, message: str, category: str = ""):
        """Логирование данных форм"""
        self._log("FORM", message, category)
    
    def auth(self, message: str, category: str = ""):
        """Логирование аутентификации"""
        self._log("AUTH", message, category)
    
    def config(self, message: str, category: str = ""):
        """Логирование конфигурации"""
        self._log("CONFIG", message, category)
    
    def backup(self, message: str, category: str = ""):
        """Логирование резервного копирования"""
        self._log("BACKUP", message, category)
    
    def reminder(self, message: str, category: str = ""):
        """Логирование напоминаний"""
        self._log("REMINDER", message, category)
    
    def notification(self, message: str, category: str = ""):
        """Логирование уведомлений"""
        self._log("NOTIFICATION", message, category)
    
    def set_debug(self, debug: bool):
        """Включает/отключает отладочный режим"""
        self.debug = debug
        if debug:
            self.info("Отладочный режим включен", "LOGGER")
        else:
            self.info("Отладочный режим отключен", "LOGGER")
    
    def get_log_level(self) -> str:
        """Возвращает текущий уровень логирования"""
        return "DEBUG" if self.debug else "INFO"
    
    def log_exception(self, exception: Exception, context: str = ""):
        """Логирует исключение с контекстом"""
        error_msg = f"Исключение в {context}: {type(exception).__name__}: {str(exception)}"
        self.error(error_msg, "EXCEPTION")
        
        if self.debug:
            import traceback
            self.debug(f"Трассировка:\n{traceback.format_exc()}", "EXCEPTION")

# Глобальный экземпляр логгера
_logger_instance = None

def get_logger(name: str = "ToDoLite", debug: bool = False) -> SimpleLogger:
    """Получает глобальный экземпляр логгера"""
    global _logger_instance
    if _logger_instance is None:
        _logger_instance = SimpleLogger(name, debug)
    return _logger_instance

# Создаем глобальный логгер для обратной совместимости
logger = get_logger()
