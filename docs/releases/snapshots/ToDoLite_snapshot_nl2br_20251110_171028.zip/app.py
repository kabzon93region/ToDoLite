from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import json
import re
import sqlite3
import os
import signal
import sys
from datetime import datetime
import html
import re as _re
from logger import logger
from markdown_utils import markdown_to_html, validate_markdown
from auth import require_auth, get_auth
from database_manager import get_db_manager
from config_manager import get_config_manager

app = Flask(__name__)
app.secret_key = 'todolite_secret_key_2025'  # Для сессий

# Добавляем фильтр markdown в Jinja2
@app.template_filter('markdown')
def markdown_filter(text):
    """Фильтр для конвертации Markdown в HTML в шаблонах"""
    if not text:
        return ""
    return markdown_to_html(text)

# Переменная для отслеживания состояния сервера
server_running = True

def signal_handler(signum, frame):
    """Обработчик сигналов для graceful shutdown"""
    global server_running
    logger.warning(f"Получен сигнал {signum}. Завершение работы...", "SIGNAL")
    server_running = False
    sys.exit(0)

# Регистрируем обработчики сигналов
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Проверяем существование таблицы и обновляем схему
    c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
    table_exists = c.fetchone()
    
    if table_exists:
        # Проверяем существование новых колонок
        c.execute("PRAGMA table_info(tasks)")
        columns = [column[1] for column in c.fetchall()]
        
        # Добавляем недостающие колонки
        new_columns = [
            ('short_description', 'TEXT'),
            ('full_description', 'TEXT'),
            ('eisenhower_priority', 'TEXT DEFAULT "not_urgent_not_important"'),
            ('assigned_to', 'TEXT'),
            ('related_threads', 'TEXT'),
            ('scheduled_date', 'DATE'),
            ('due_date', 'DATE'),
            ('reminder_time', 'DATETIME'),
            ('tags', 'TEXT'),
            ('completed_at', 'TIMESTAMP')
        ]
        
        for col_name, col_type in new_columns:
            if col_name not in columns:
                c.execute(f"ALTER TABLE tasks ADD COLUMN {col_name} {col_type}")
        
        # Обновляем статус по умолчанию если нужно
        if 'status' in columns:
            c.execute("UPDATE tasks SET status = 'new' WHERE status = 'todo'")
    else:
        # Создаем новую таблицу
        c.execute('''CREATE TABLE tasks
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      title TEXT NOT NULL,
                      short_description TEXT,
                      full_description TEXT,
                      status TEXT DEFAULT 'new',
                      priority TEXT DEFAULT 'medium',
                      eisenhower_priority TEXT DEFAULT 'not_urgent_not_important',
                      assigned_to TEXT,
                      related_threads TEXT,
                      scheduled_date DATE,
                      due_date DATE,
                      reminder_time DATETIME,
                      tags TEXT,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      completed_at TIMESTAMP,
                      archived BOOLEAN DEFAULT 0,
                      archived_at TIMESTAMP,
                      archived_from_status TEXT)''')
    
    # Создаем таблицу комментариев
    c.execute('''CREATE TABLE IF NOT EXISTS task_comments
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  task_id INTEGER NOT NULL,
                  comment TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE CASCADE)''')
    
    # Проверяем и добавляем новые поля для архивирования
    try:
        c.execute("ALTER TABLE tasks ADD COLUMN archived BOOLEAN DEFAULT 0")
        logger.database("Добавлено поле archived в таблицу tasks", "MIGRATION")
    except sqlite3.OperationalError:
        pass  # Поле уже существует
    
    try:
        c.execute("ALTER TABLE tasks ADD COLUMN archived_at TIMESTAMP")
        logger.database("Добавлено поле archived_at в таблицу tasks", "MIGRATION")
    except sqlite3.OperationalError:
        pass  # Поле уже существует
    
    try:
        c.execute("ALTER TABLE tasks ADD COLUMN archived_from_status TEXT")
        logger.database("Добавлено поле archived_from_status в таблицу tasks", "MIGRATION")
    except sqlite3.OperationalError:
        pass  # Поле уже существует
    
    conn.commit()
    conn.close()

# Получить все задачи (исключая архивированные)
def get_tasks():
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("SELECT * FROM tasks WHERE archived = 0 OR archived IS NULL ORDER BY created_at DESC")
    tasks = c.fetchall()
    conn.close()
    return tasks

# Получить задачи по режиму отображения
def get_tasks_by_mode(mode):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # В обоих режимах сортируем по приоритету: high -> medium -> low, затем по сроку
    if mode == 'eisenhower':
        c.execute("""
            SELECT 
                id,
                title,
                short_description,
                full_description,
                status,
                priority,
                eisenhower_priority,
                assigned_to,
                related_threads,
                scheduled_date,
                due_date,
                created_at,
                updated_at,
                completed_at,
                tags
            FROM tasks
            WHERE archived = 0 OR archived IS NULL
            ORDER BY 
                CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
                COALESCE(due_date, '') ASC
        """)
    elif mode == 'kanban':
        c.execute("""
            SELECT 
                id,
                title,
                short_description,
                full_description,
                status,
                priority,
                eisenhower_priority,
                assigned_to,
                related_threads,
                scheduled_date,
                due_date,
                created_at,
                updated_at,
                completed_at,
                tags
            FROM tasks
            WHERE archived = 0 OR archived IS NULL
            ORDER BY 
                CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
                COALESCE(due_date, '') ASC
        """)
    else:
        c.execute("""
            SELECT 
                id,
                title,
                short_description,
                full_description,
                status,
                priority,
                eisenhower_priority,
                assigned_to,
                related_threads,
                scheduled_date,
                due_date,
                created_at,
                updated_at,
                completed_at,
                tags
            FROM tasks 
            ORDER BY created_at DESC
        """)
    
    tasks = c.fetchall()
    conn.close()
    return tasks

# Получить задачи по режиму отображения с комментариями для поиска
def get_tasks_by_mode_with_comments(mode):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Получаем все задачи
    if mode == 'eisenhower':
        c.execute("""
            SELECT 
                id,
                title,
                short_description,
                full_description,
                status,
                priority,
                eisenhower_priority,
                assigned_to,
                related_threads,
                scheduled_date,
                due_date,
                created_at,
                updated_at,
                completed_at,
                tags
            FROM tasks
            WHERE archived = 0 OR archived IS NULL
            ORDER BY 
                CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
                COALESCE(due_date, '') ASC
        """)
    elif mode == 'kanban':
        c.execute("""
            SELECT 
                id,
                title,
                short_description,
                full_description,
                status,
                priority,
                eisenhower_priority,
                assigned_to,
                related_threads,
                scheduled_date,
                due_date,
                created_at,
                updated_at,
                completed_at,
                tags
            FROM tasks
            WHERE archived = 0 OR archived IS NULL
            ORDER BY 
                CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
                COALESCE(due_date, '') ASC
        """)
    else:
        c.execute("""
            SELECT 
                id,
                title,
                short_description,
                full_description,
                status,
                priority,
                eisenhower_priority,
                assigned_to,
                related_threads,
                scheduled_date,
                due_date,
                created_at,
                updated_at,
                completed_at,
                tags
            FROM tasks 
            ORDER BY created_at DESC
        """)
    
    tasks = c.fetchall()
    
    # Для каждой задачи получаем комментарии и добавляем их к данным задачи
    tasks_with_comments = []
    for task in tasks:
        task_id = task[0]
        c.execute("SELECT comment FROM task_comments WHERE task_id = ?", (task_id,))
        comments = c.fetchall()
        # Объединяем все комментарии в одну строку
        comments_text = ' '.join([comment[0] for comment in comments])
        # Добавляем комментарии как дополнительный элемент к кортежу задачи
        task_with_comments = task + (comments_text,)
        tasks_with_comments.append(task_with_comments)
    
    conn.close()
    return tasks_with_comments


def _clean_json(text: str) -> str:
    # Remove BOM
    text = text.lstrip('\ufeff')
    # Remove // comments
    text = re.sub(r"(^|\s)//.*$", "", text, flags=re.MULTILINE)
    # Remove /* */ comments
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    # Remove trailing commas before } or ]
    text = re.sub(r",\s*(\}|\])", r"\1", text)
    return text

def load_config():
    """Загружает конфигурацию из config.json"""
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            raw = f.read()
            try:
                return json.loads(raw)
            except Exception:
                # Пытаемся почистить и распарсить с мягкой толерантностью к комментам/висячим запятым
                cleaned = _clean_json(raw)
                return json.loads(cleaned)
    except Exception:
        return {
            "statuses_order": ["new","think","later","waiting","working","tracking","done","cancelled"],
            "statuses_labels": {
                "new": "🆕 Новая","think": "🤔 На подумать","later": "⏰ На потом","waiting": "⏳ Ждем кого-то","working": "⚡ В работе","tracking": "👀 Отслеживаем","done": "✅ Готово","cancelled": "❌ Отменено"
            },
            "eisenhower_order": ["urgent_important","urgent_not_important","not_urgent_important","not_urgent_not_important"],
            "eisenhower_labels": {
                "urgent_important": "🔥 Важные и срочные","urgent_not_important": "⚡ Срочные не важные","not_urgent_important": "⭐ Важные не срочные","not_urgent_not_important": "📋 Не важные не срочные"
            }
        }


# Фильтр Jinja для форматирования даты в российском формате (ДД.ММ.ГГГГ)
def format_date_ru(value: str):
    if not value:
        return ''
    try:
        # Попытка ISO с временем
        # Обрезаем возможные микросекунды/таймзону
        cleaned = str(value).strip()
        # Если только дата
        try:
            dt = datetime.strptime(cleaned[:10], '%Y-%m-%d')
            return dt.strftime('%d.%m.%Y')
        except Exception as e:
            logger.debug(f"Ошибка форматирования даты: {e}", "FORMAT")
        # Дата+время
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S.%f'):
            try:
                dt = datetime.strptime(cleaned[:26], fmt)
                return dt.strftime('%d.%m.%Y')
            except Exception:
                continue
        # Последняя попытка: fromisoformat если доступно
        try:
            dt = datetime.fromisoformat(cleaned)
            return dt.strftime('%d.%m.%Y')
        except Exception:
            return cleaned
    except Exception:
        return ''


def format_datetime_ru(value: str):
    """Форматирует дату и время в русском формате"""
    if not value:
        return ''
    try:
        cleaned = str(value).strip()
        # Попытка ISO с временем
        for fmt in ('%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S.%f'):
            try:
                dt = datetime.strptime(cleaned[:26], fmt)
                return dt.strftime('%d.%m.%Y %H:%M')
            except Exception:
                continue
        # Последняя попытка: fromisoformat если доступно
        try:
            dt = datetime.fromisoformat(cleaned)
            return dt.strftime('%d.%m.%Y %H:%M')
        except Exception:
            return cleaned
    except Exception:
        return ''

# Регистрируем фильтры в Jinja
app.jinja_env.filters['ru_date'] = format_date_ru
app.jinja_env.filters['ru_datetime'] = format_datetime_ru


# Безопасная очистка HTML: убираем опасные теги и атрибуты
_ALLOWED_TAGS = {
    'b','strong','i','em','u','s','strike','span','div','p','br','hr',
    'ul','ol','li','blockquote','pre','code','a','h1','h2','h3','h4','h5','h6',
    'table','tr','td','th','tbody','thead','tfoot','colgroup','col'
}
_ALLOWED_ATTRS = {
    'a': {'href','title','target','rel'},
    'span': {'style'},
    'div': {'style'},
    'p': {'style'},
    'code': {'class'},
    'table': {'style','border','cellpadding','cellspacing','width'},
    'tr': {'style','height'},
    'td': {'style','width','height','colspan','rowspan','class'},
    'th': {'style','width','height','colspan','rowspan','class'},
    'tbody': {'style'},
    'thead': {'style'},
    'tfoot': {'style'},
    'colgroup': {'style'},
    'col': {'style','width'},
    '*': {'style'}
}

_STYLE_WHITELIST = _re.compile(r"^(color|background-color|text-align|font-weight|font-style|text-decoration|border|border-collapse|width|height|padding|margin):", _re.I)

def sanitize_html(raw: str) -> str:
    if not raw:
        return ''
    # Убираем опасные теги целиком
    cleaned = _re.sub(r"<(script|style)[\s\S]*?>[\s\S]*?<\/\1>", "", raw, flags=_re.I)
    # Удаляем on* обработчики и javascript: ссылки
    cleaned = _re.sub(r"\son\w+\s*=\s*\"[\s\S]*?\"", "", cleaned, flags=_re.I)
    cleaned = _re.sub(r"\son\w+\s*=\s*'[^']*'", "", cleaned, flags=_re.I)
    cleaned = _re.sub(r"\son\w+\s*=\s*[^\s>]+", "", cleaned, flags=_re.I)
    cleaned = _re.sub(r"(href|src)\s*=\s*(['\"])javascript:[^\2]*\2", r"\1=\2#\2", cleaned, flags=_re.I)

    # Разрешаем только whitelisted теги; остальные заменяем на текст
    def _replace_tag(match):
        groups = match.groups()
        if len(groups) < 3:
            return html.escape(match.group(0))
        
        closing = groups[0]
        name = groups[1].lower()
        attrs = groups[2] if len(groups) > 2 else ''
        
        if name not in _ALLOWED_TAGS:
            # Экранируем весь тег
            return html.escape(match.group(0))
        
        # Фильтруем атрибуты
        allowed_for_tag = _ALLOWED_ATTRS.get(name, set()) | _ALLOWED_ATTRS.get('*', set())
        def _attr_filter(attr_match):
            attr_groups = attr_match.groups()
            if len(attr_groups) < 3:
                return ''
            attr_name = attr_groups[0].lower()
            quote = attr_groups[1]
            val = attr_groups[2]
            if attr_name not in allowed_for_tag:
                return ''
            if attr_name == 'style':
                # Оставляем только разрешенные CSS свойства
                safe_parts = []
                for part in val.split(';'):
                    p = part.strip()
                    if p and _STYLE_WHITELIST.match(p):
                        safe_parts.append(p)
                val = '; '.join(safe_parts)
            if attr_name == 'href' and val.strip().lower().startswith('javascript:'):
                val = '#'
            return f" {attr_name}={quote}{html.escape(val, quote=True)}{quote}"

        safe_attrs = _re.sub(r"\s*(\w+)\s*=\s*([\"'])([\s\S]*?)\2", _attr_filter, attrs)
        return f"<{closing}{name}{safe_attrs}>"

    cleaned = _re.sub(r"<(\/?)([A-Za-z0-9]+)([^>]*)>", _replace_tag, cleaned)
    return cleaned

# Получить задачу по ID с комментариями
def get_task_with_comments(task_id):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Получаем задачу
    c.execute("""
        SELECT 
            id,
            title,
            short_description,
            full_description,
            status,
            priority,
            eisenhower_priority,
            assigned_to,
            related_threads,
            scheduled_date,
            due_date,
            reminder_time,
            created_at,
            updated_at,
            completed_at,
            tags,
            archived,
            archived_at,
            archived_from_status
        FROM tasks WHERE id = ?
    """, (task_id,))
    task = c.fetchone()
    
    # Получаем комментарии
    # Новые комментарии первыми
    c.execute("SELECT * FROM task_comments WHERE task_id = ? ORDER BY created_at DESC", (task_id,))
    comments = c.fetchall()
    
    conn.close()
    return task, comments

# Добавить новую задачу
def add_task(title, short_description, full_description, status, priority, eisenhower_priority, 
             assigned_to, related_threads, scheduled_date, due_date, reminder_time, tags):
    logger.task(f"Создание новой задачи: '{title[:30]}...'", "CREATE")
    logger.database(f"Сохранение в БД: assigned_to='{assigned_to}', threads='{related_threads}'", "DB_WRITE")
    
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("""INSERT INTO tasks (title, short_description, full_description, status, priority, 
                 eisenhower_priority, assigned_to, related_threads, scheduled_date, due_date, reminder_time, tags) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
              (title, short_description, full_description, status, priority, eisenhower_priority,
               assigned_to, related_threads, scheduled_date, due_date, reminder_time, tags))
    conn.commit()
    conn.close()
    
    logger.success(f"Задача успешно создана: '{title[:30]}...'", "CREATE")

# Обновить задачу
def update_task(task_id, title, short_description, full_description, status, priority, 
                eisenhower_priority, assigned_to, related_threads, scheduled_date, due_date, reminder_time, tags):
    logger.task(f"Обновление задачи ID {task_id}: '{title[:30]}...'", "UPDATE")
    logger.database(f"Обновление в БД: status='{status}', threads='{related_threads}', reminder_time='{reminder_time}'", "DB_WRITE")
    
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    # Если статус переводится в 'done', проставляем completed_at только один раз
    c.execute("""
        UPDATE tasks SET 
            title=?, 
            short_description=?, 
            full_description=?, 
            status=?, 
            priority=?, 
            eisenhower_priority=?, 
            assigned_to=?, 
            related_threads=?, 
            tags=?,
            scheduled_date=?, 
            due_date=?, 
            reminder_time=?,
            updated_at=CURRENT_TIMESTAMP,
            completed_at=CASE 
                WHEN ?='done' AND (completed_at IS NULL OR completed_at='') THEN CURRENT_TIMESTAMP 
                ELSE completed_at 
            END
        WHERE id=?
    """,
        (
            title, short_description, full_description, status, priority, eisenhower_priority,
            assigned_to, related_threads, tags, scheduled_date, due_date, reminder_time, status, task_id
        )
    )
    conn.commit()
    conn.close()
    
    logger.success(f"Задача ID {task_id} успешно обновлена", "UPDATE")

# Добавить комментарий к задаче
def add_comment(task_id, comment):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("INSERT INTO task_comments (task_id, comment) VALUES (?, ?)", (task_id, comment))
    conn.commit()
    conn.close()

# Удалить задачу
def delete_task(task_id):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()

# Архивировать задачу
def archive_task(task_id):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Получаем текущий статус задачи
    c.execute("SELECT status FROM tasks WHERE id = ?", (task_id,))
    result = c.fetchone()
    if not result:
        conn.close()
        return False
    
    current_status = result[0]
    
    # Архивируем задачу
    c.execute("""
        UPDATE tasks 
        SET archived = 1, 
            archived_at = CURRENT_TIMESTAMP,
            archived_from_status = ?
        WHERE id = ?
    """, (current_status, task_id))
    
    conn.commit()
    conn.close()
    return True

# Восстановить задачу из архива
def restore_task(task_id):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Получаем статус, из которого была архивирована задача
    c.execute("SELECT archived_from_status FROM tasks WHERE id = ? AND archived = 1", (task_id,))
    result = c.fetchone()
    if not result:
        conn.close()
        return False
    
    original_status = result[0]
    
    # Восстанавливаем задачу
    c.execute("""
        UPDATE tasks 
        SET archived = 0, 
            archived_at = NULL,
            archived_from_status = NULL,
            status = ?
        WHERE id = ?
    """, (original_status, task_id))
    
    conn.commit()
    conn.close()
    return True

# Получить архивированные задачи
def get_archived_tasks():
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("""
        SELECT * FROM tasks 
        WHERE archived = 1 
        ORDER BY archived_at DESC
    """)
    tasks = c.fetchall()
    conn.close()
    return tasks

@app.route('/')
@require_auth
def index():
    mode = request.args.get('mode', 'kanban')
    logger.http(f"Запрос главной страницы, режим: {mode}", "HTTP_GET")
    tasks = get_tasks_by_mode_with_comments(mode)
    cfg = load_config()
    logger.info(f"Загружено {len(tasks)} задач для режима '{mode}'", "PAGE_LOAD")
    return render_template('index.html', tasks=tasks, current_mode=mode, cfg=cfg)

@app.route('/task/<int:task_id>')
@require_auth
def view_task(task_id):
    logger.http(f"Запрос деталей задачи ID {task_id}", "HTTP_GET")
    task, comments = get_task_with_comments(task_id)
    if not task:
        logger.error(f"Задача ID {task_id} не найдена", "TASK_NOT_FOUND")
        return "Задача не найдена", 404
    cfg = load_config()
    logger.info(f"Загружены детали задачи ID {task_id}, комментариев: {len(comments)}", "TASK_VIEW")
    return render_template('task_detail.html', task=task, comments=comments, cfg=cfg)

@app.route('/archive')
@require_auth
def archive():
    logger.http("Запрос страницы архива", "HTTP_GET")
    tasks = get_archived_tasks()
    cfg = load_config()
    logger.info(f"Загружено {len(tasks)} архивированных задач", "ARCHIVE_VIEW")
    return render_template('archive.html', tasks=tasks, cfg=cfg)

@app.route('/add_task', methods=['POST'])
@require_auth
def add_task_route():
    logger.http("Запрос создания новой задачи", "HTTP_POST")
    
    title = request.form['title']
    short_description = request.form.get('short_description', '')
    full_description = request.form.get('full_description', '')
    status = request.form.get('status', 'new')
    priority = request.form.get('priority', 'medium')
    eisenhower_priority = request.form.get('eisenhower_priority', 'not_urgent_not_important')
    assigned_to = request.form.get('assigned_to', '')
    related_threads = request.form.get('related_threads', '')
    tags = request.form.get('tags', '')
    scheduled_date = request.form.get('scheduled_date', '')
    due_date = request.form.get('due_date', '')
    reminder_time = request.form.get('reminder_time', '')
    
    # Отладочная информация
    logger.form(f"related_threads = '{related_threads}'", "FORM_DATA")
    logger.form(f"assigned_to = '{assigned_to}'", "FORM_DATA")
    logger.form(f"scheduled_date = '{scheduled_date}'", "FORM_DATA")
    logger.form(f"due_date = '{due_date}'", "FORM_DATA")
    logger.form(f"reminder_time = '{reminder_time}'", "FORM_DATA")
    
    add_task(title, short_description, full_description, status, priority, eisenhower_priority,
             assigned_to, related_threads, scheduled_date, due_date, reminder_time, tags)
    return redirect(url_for('index'))

@app.route('/update_task/<int:task_id>', methods=['POST'])
@require_auth
def update_task_route(task_id):
    logger.http(f"Запрос обновления задачи ID {task_id}", "HTTP_POST")
    
    title = request.form['title']
    short_description = request.form.get('short_description', '')
    full_description = request.form.get('full_description', '')
    status = request.form.get('status', 'new')
    priority = request.form.get('priority', 'medium')
    eisenhower_priority = request.form.get('eisenhower_priority', 'not_urgent_not_important')
    assigned_to = request.form.get('assigned_to', '')
    related_threads = request.form.get('related_threads', '')
    tags = request.form.get('tags', '')
    scheduled_date = request.form.get('scheduled_date', '')
    due_date = request.form.get('due_date', '')
    reminder_time = request.form.get('reminder_time', '')
    
    # Отладочная информация
    logger.form(f"UPDATE - reminder_time = '{reminder_time}'", "FORM_DATA")
    logger.form(f"UPDATE - scheduled_date = '{scheduled_date}'", "FORM_DATA")
    logger.form(f"UPDATE - due_date = '{due_date}'", "FORM_DATA")
    
    update_task(task_id, title, short_description, full_description, status, priority,
                eisenhower_priority, assigned_to, related_threads, scheduled_date, due_date, reminder_time, tags)
    return redirect(url_for('view_task', task_id=task_id))

@app.route('/add_comment/<int:task_id>', methods=['POST'])
@require_auth
def add_comment_route(task_id):
    logger.http(f"Запрос добавления комментария к задаче ID {task_id}", "HTTP_POST")
    
    comment = request.form.get('comment', '').strip()
    if not comment:
        logger.warning(f"Пустой комментарий для задачи ID {task_id}", "EMPTY_COMMENT")
        return redirect(url_for('view_task', task_id=task_id, open_edit=1))
    
    # Валидируем Markdown
    is_valid, error_msg = validate_markdown(comment)
    if not is_valid:
        logger.warning(f"Невалидный Markdown в комментарии для задачи ID {task_id}: {error_msg}", "INVALID_MARKDOWN")
        return redirect(url_for('view_task', task_id=task_id, open_edit=1))
    
    # Конвертируем Markdown в HTML
    comment_html = markdown_to_html(comment)
    
    # Сохраняем оригинальный Markdown текст
    add_comment(task_id, comment)
    logger.success(f"Комментарий добавлен к задаче ID {task_id}", "COMMENT_ADD")
    # После добавления комментария раскрываем блок редактирования
    return redirect(url_for('view_task', task_id=task_id, open_edit=1))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Страница входа в систему"""
    auth = get_auth()
    
    # Если аутентификация отключена, перенаправляем на главную
    if not auth.users:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        if auth.check_auth(username, password):
            session['authenticated'] = True
            session['username'] = username
            logger.info(f"Пользователь {username} вошел в систему", "AUTH")
            return redirect(url_for('index'))
        else:
            logger.warning(f"Неудачная попытка входа: {username}", "AUTH")
            return render_template('login.html', error="Неверное имя пользователя или пароль")
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Выход из системы"""
    auth = get_auth()
    auth.logout()
    return redirect(url_for('login'))

@app.route('/markdown_preview', methods=['POST'])
def markdown_preview_route():
    """API для предпросмотра Markdown"""
    try:
        markdown_text = request.json.get('markdown', '')
        
        # Валидируем Markdown
        is_valid, error_msg = validate_markdown(markdown_text)
        if not is_valid:
            return jsonify({
                'success': False,
                'error': error_msg,
                'html': ''
            })
        
        # Конвертируем в HTML
        html = markdown_to_html(markdown_text)
        
        return jsonify({
            'success': True,
            'html': html,
            'error': ''
        })
        
    except Exception as e:
        logger.error(f"Ошибка предпросмотра Markdown: {e}", "MARKDOWN_PREVIEW")
        return jsonify({
            'success': False,
            'error': str(e),
            'html': ''
        })

@app.route('/delete_task/<int:task_id>')
def delete_task_route(task_id):
    logger.http(f"Запрос удаления задачи ID {task_id}", "HTTP_GET")
    logger.task(f"Удаление задачи ID {task_id}", "DELETE")
    delete_task(task_id)
    logger.success(f"Задача ID {task_id} успешно удалена", "DELETE")
    return redirect(url_for('index'))

@app.route('/archive_task/<int:task_id>')
def archive_task_route(task_id):
    logger.http(f"Запрос архивирования задачи ID {task_id}", "HTTP_GET")
    logger.task(f"Архивирование задачи ID {task_id}", "ARCHIVE")
    if archive_task(task_id):
        logger.success(f"Задача ID {task_id} успешно архивирована", "ARCHIVE")
    else:
        logger.error(f"Ошибка архивирования задачи ID {task_id}", "ARCHIVE")
    return redirect(url_for('index'))

@app.route('/restore_task/<int:task_id>')
def restore_task_route(task_id):
    logger.http(f"Запрос восстановления задачи ID {task_id}", "HTTP_GET")
    logger.task(f"Восстановление задачи ID {task_id}", "RESTORE")
    if restore_task(task_id):
        logger.success(f"Задача ID {task_id} успешно восстановлена", "RESTORE")
    else:
        logger.error(f"Ошибка восстановления задачи ID {task_id}", "RESTORE")
    return redirect(url_for('archive'))

@app.route('/mark_done/<int:task_id>')
def mark_done_route(task_id):
    """Отметить задачу как выполненную"""
    logger.http(f"Запрос отметки задачи ID {task_id} как выполненной", "HTTP_GET")
    logger.task(f"Отметка задачи ID {task_id} как выполненной", "MARK_DONE")
    
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    c.execute("""
        UPDATE tasks SET 
            status = 'done',
            completed_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (task_id,))
    
    conn.commit()
    conn.close()
    
    logger.success(f"Задача ID {task_id} отмечена как выполненная", "MARK_DONE")
    return redirect(url_for('view_task', task_id=task_id))

@app.route('/update_task_status', methods=['POST'])
def update_task_status():
    """API endpoint для обновления статуса задачи через drag&drop"""
    logger.http("API запрос обновления статуса задачи", "API_POST")
    
    data = request.get_json()
    task_id = data.get('task_id')
    new_status = data.get('status')
    
    if not task_id or not new_status:
        logger.error(f"Неверные данные API: task_id={task_id}, status={new_status}", "API_ERROR")
        return {'success': False, 'error': 'Missing task_id or status'}, 400
    
    logger.task(f"Обновление статуса задачи ID {task_id} на '{new_status}'", "STATUS_UPDATE")
    
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Обновляем только статус задачи
    c.execute("""
        UPDATE tasks SET 
            status = ?, 
            updated_at = CURRENT_TIMESTAMP,
            completed_at = CASE 
                WHEN ? = 'done' AND (completed_at IS NULL OR completed_at = '') THEN CURRENT_TIMESTAMP 
                ELSE completed_at 
            END
        WHERE id = ?
    """, (new_status, new_status, task_id))
    
    conn.commit()
    conn.close()
    
    logger.success(f"Статус задачи ID {task_id} обновлен на '{new_status}'", "STATUS_UPDATE")
    return {'success': True}

@app.route('/api/tags')
def get_tags():
    """API для получения всех тегов с количеством задач"""
    logger.http("API запрос получения тегов", "API_GET")
    
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    
    # Получаем все теги и считаем количество задач для каждого
    c.execute("""
        SELECT tags, COUNT(*) as count 
        FROM tasks 
        WHERE tags IS NOT NULL AND tags != '' 
        GROUP BY tags
        ORDER BY count DESC, tags ASC
    """)
    
    tags_data = c.fetchall()
    conn.close()
    
    # Парсим теги и создаем список уникальных тегов с количеством
    tag_counts = {}
    for tags_string, count in tags_data:
        if tags_string:
            # Разбиваем теги по пробелам и очищаем от # если нужно
            tags = [tag.strip() for tag in tags_string.split() if tag.strip()]
            for tag in tags:
                # Убираем # из начала если есть
                clean_tag = tag[1:] if tag.startswith('#') else tag
                if clean_tag not in tag_counts:
                    tag_counts[clean_tag] = 0
                tag_counts[clean_tag] += count
    
    # Сортируем по количеству, затем по алфавиту
    sorted_tags = sorted(tag_counts.items(), key=lambda x: (-x[1], x[0]))
    
    logger.info(f"Возвращено {len(sorted_tags)} уникальных тегов", "API_TAGS")
    return {'tags': [{'tag': tag, 'count': count} for tag, count in sorted_tags]}

@app.route('/test_api')
def test_api_page():
    return app.send_static_file('test_api.html')

if __name__ == '__main__':
    logger.info("Запуск ToDoLite приложения", "STARTUP")
    logger.database("Инициализация базы данных", "DB_INIT")
    init_db()
    logger.success("База данных инициализирована", "DB_INIT")
    logger.http("Запуск Flask сервера на http://0.0.0.0:5000", "SERVER_START")
    app.run(debug=True, host='0.0.0.0', port=5000)
